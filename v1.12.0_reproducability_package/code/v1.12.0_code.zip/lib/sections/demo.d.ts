import { JupyterFrontEnd } from '@jupyterlab/application';
import { INotebookTracker } from '@jupyterlab/notebook';
export declare class DemoSection {
    private app;
    private notebooks;
    constructor(app: JupyterFrontEnd, notebooks?: INotebookTracker);
    render(): string;
    handleDemoButton(): Promise<void>;
}
