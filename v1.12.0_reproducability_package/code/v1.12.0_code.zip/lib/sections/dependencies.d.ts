import { INotebookTracker } from '@jupyterlab/notebook';
import { JupyterFrontEnd } from '@jupyterlab/application';
export declare class DependenciesSection {
    private notebooks;
    private app;
    constructor(app: JupyterFrontEnd, notebooks?: INotebookTracker);
    render(): string;
    handleDependenciesButton(): Promise<void>;
    private extractPackagesFromCells;
    private parsePackageString;
    private getInstalledVersions;
    private getPipPackageVersion;
    private getCondaPackageVersion;
    private executePythonCommand;
    private createEnvironmentYaml;
    private addEnvironmentCell;
    private delay;
}
