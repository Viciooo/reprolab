import { INotebookTracker } from '@jupyterlab/notebook';
import { JupyterFrontEnd } from '@jupyterlab/application';
export declare class ZenodoSection {
    private notebooks;
    private app;
    constructor(app: JupyterFrontEnd, notebooks?: INotebookTracker);
    render(): string;
    handleZenodoButton(modal: HTMLElement): void;
    handleTestButton(): Promise<void>;
    private validateNotebookContext;
    private addReproducabilityCells;
    private executeFirstCell;
    private delay;
}
