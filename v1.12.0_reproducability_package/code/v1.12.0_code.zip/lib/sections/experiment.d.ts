import { INotebookTracker } from '@jupyterlab/notebook';
import { JupyterFrontEnd } from '@jupyterlab/application';
export declare class ExperimentSection {
    private readonly notebooks;
    private readonly app;
    constructor(app: JupyterFrontEnd, notebooks?: INotebookTracker);
    render(): string;
    private createExperimentContent;
    private getDescriptionText;
    private createExperimentButton;
    createExperiment(): Promise<void>;
    private validateNotebookContext;
    private saveNotebookState;
    private addExperimentCells;
    private addStartExperimentCell;
    private addEndExperimentCell;
    private executeExperiment;
    private delay;
}
