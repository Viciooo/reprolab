export declare class ArchiveSection {
    private accessKey;
    private secretKey;
    private bucketName;
    private initialized;
    constructor();
    private initialize;
    render(): string;
    handleSaveButton(node: HTMLElement): Promise<void>;
    private loadAWSEnv;
    private saveAWSEnv;
}
