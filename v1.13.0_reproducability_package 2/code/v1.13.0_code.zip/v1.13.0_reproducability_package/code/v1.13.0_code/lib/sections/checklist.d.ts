export declare class ChecklistSection {
    private checklist;
    private checked;
    constructor();
    render(): string;
    handleCheckboxChange(event: Event): void;
    loadChecklistState(): Promise<void>;
    saveChecklistState(): Promise<void>;
    getChecklist(): string[];
    getChecked(): Record<string, boolean>;
}
