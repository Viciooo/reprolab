import { ReactWidget } from '@jupyterlab/apputils';
import { IGitExtension } from '@jupyterlab/git';
export declare class GitTagManagerWidget extends ReactWidget {
    private gitExtension;
    private token;
    private context;
    private remoteTags;
    private tagName;
    private tagMessage;
    constructor(gitExtension: IGitExtension, token: string);
    private loadContext;
    private parseGithubRepo;
    private listRemoteTags;
    private createTag;
    render(): React.ReactElement;
}
