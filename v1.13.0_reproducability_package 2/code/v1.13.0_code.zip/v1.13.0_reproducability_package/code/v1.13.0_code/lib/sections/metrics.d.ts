import { INotebookTracker } from '@jupyterlab/notebook';
export declare class MetricsSection {
    private notebooks;
    constructor(notebooks?: INotebookTracker);
    render(): string;
    handleMetricsButton(): void;
}
