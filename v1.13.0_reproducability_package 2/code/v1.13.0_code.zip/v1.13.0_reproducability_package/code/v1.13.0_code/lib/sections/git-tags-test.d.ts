import { IGitExtension } from '@jupyterlab/git';
export declare class GitTagsTestSection {
    private gitExtension;
    private gitTagManager;
    constructor(gitExtension: IGitExtension | null);
    render(): string;
}
