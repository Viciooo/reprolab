import { INotebookTracker } from '@jupyterlab/notebook';
import { JupyterFrontEnd } from '@jupyterlab/application';
export declare class EnvironmentSection {
    private readonly notebooks;
    private readonly app;
    constructor(app: JupyterFrontEnd, notebooks?: INotebookTracker);
    render(): string;
    private createEnvironmentContent;
    private getDescriptionText;
    private getFreezeDescriptionText;
    private createEnvironmentButton;
    private createFreezeDepsButton;
    createEnvironment(): Promise<void>;
    addFreezeDepsCell(): Promise<void>;
    private validateNotebookContext;
    private addEnvironmentCell;
    private executeEnvironmentCell;
    private addFreezeDepsCellToNotebook;
    private delay;
}
