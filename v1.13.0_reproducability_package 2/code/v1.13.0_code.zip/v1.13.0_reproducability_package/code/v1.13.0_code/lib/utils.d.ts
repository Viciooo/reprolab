/**
 * Utility functions for the ReproLab extension
 */
/**
 * Creates a section element with a title and content
 */
export declare function createSection(title: string, content: string): HTMLElement;
/**
 * Creates a button element with the specified ID and text
 */
export declare function createButton(id: string, text: string): HTMLButtonElement;
/**
 * Creates an input element with the specified ID, type, placeholder, default value, and placeholder text
 */
export declare function createInput(id: string, type: string, placeholder: string, defaultValue?: string, placeholderText?: string): HTMLInputElement;
/**
 * Gets the XSRF token from cookies
 */
export declare function getXsrfToken(): string | null;
