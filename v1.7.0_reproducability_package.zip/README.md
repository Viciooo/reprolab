# Reproducibility Package for Tag: v1.7.0

This package contains all the code and data needed to reproduce the results from git tag 'v1.7.0'.

## Contents

### Code Package
- `code/v1.7.0_code.zip`: Contains all Jupyter notebooks and Python files

### Data Packages

## Usage

1. Extract this package
2. Extract the code package to get the notebooks
3. Extract the data packages to get the cached data
4. Run the notebooks with the reprolab environment

## Package Creation Details
- Created on: 2025-06-20T21:50:47.709606+00:00
- Git tag: v1.7.0
- Total notebooks: 1
- Total data packages: 0
